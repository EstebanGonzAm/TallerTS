var Serie = /** @class */ (function () {
    function Serie(idS, nameS, channelS, seasonsS, descriptionS, linkS, imageS) {
        this.id = idS;
        this.name = nameS;
        this.channel = channelS;
        this.seasons = seasonsS;
        this.description = descriptionS;
        this.link = linkS;
        this.image = imageS;
    }
    return Serie;
}());
export { Serie };
